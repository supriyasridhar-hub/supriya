// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
   $.get("https://reqres.in/api/users", function(data, status){
    arrayTest = data.data;
    console.log(arrayTest);
     arrayTest.forEach(function(data){
       var tr = $('<tr>');
       tr.append('<td>' + data.first_name + '</td>');
       tr.append('<td>'+data.email+'</td>');
       tr.append('<td><img src='+data.avatar+'/></td>');
        $('#userTable').append(tr);
     });
    
       
    
});
  $("form[name='registration']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      username: "required",
      password: {
        required: true,
        minlength: 5
      }
    },
    // Specify validation error messages
    messages: {
        username: "Please enter your username",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});